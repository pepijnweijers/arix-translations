### List of all translations

**[Indonesian Translation](https://github.com/dwitavelany/arix-translations)** -
*credits:* Dwitavelany

**[Swedish Translation](https://github.com/PurpleWho/arix-translations)** -
*credits:* itspurple.dev

**[French Translation](https://github.com/HoatikaNess/arix-translations-french)** -
*credits:* HoatikaNess

**[Portuguese (Brazil)](https://github.com/tifannypurple/arix-translations)** -
*credits:* HoatikaNess
