<?php

return [
    'account-activity-log' => 'Logurile Activitatii in Cont',
    'activity-log' => 'Loguri Activitati',
    'clear-filters' => 'Sterge Filtrele',
    'metadata' => 'Metadata',
    'close' => 'Inchide',
    'no-logs-server' => 'Nu exista loguri pentru acest server.'
];