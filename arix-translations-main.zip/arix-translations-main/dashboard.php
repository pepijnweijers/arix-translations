<?php

return [
    'join-our-discord' => 'Alatura-te Discordului Nostru',
    'members-online' => 'Membrii Online',
    'billing-area' => 'Zona de Facturare',
    'manage-your-services' => 'Gestioneaza-ti serviciile',
    'supportcenter' => 'Centru de Suport',
    'get-support' => 'Obtine Suport',
    'server-status' => 'Statusul Serverelor',
    'check-server-status' => 'Verifica statusul server-ului',
    'welcome-back' => 'Bine ai revenit',
    'all-servers-you-have-access-to' => 'Aici poti vedea toate serverele la care ai acces.',
    'your-servers' => 'Se afiseaza serverele tale',
    'others-servers' => 'Se afiseaza alte\' servere',
    'there-are-no-servers' => 'Nu sunt alte servere pe care le poti vedea.',
    'there-are-no-servers-associated' => 'Nu sunt servere asociate cu contul tau.',
    'manage-server' => 'Gestioneaza-ti Server-ul',
];