<?php

return[
    'network' => 'Internet',
    'manage-allocation' => 'Gestioneaza Alocarea',
    'create-allocation' => 'Creaza o Alocare',
    'currently-using' => 'In prezent folosesti {{current}} din {{max}} alocarile permise pentru acest server.',

    'IP' => 'IP',
    'port' => 'Port',
    'notes' => 'Note',
    'primary' => 'Primar',
    'make-primary' => 'Faceti Principal',

    'remove-allocation' => 'Sterge Alocarea',
    'remove-allocation-description' => 'Aceasta alocare va fi stearsa imediat din server-ul tau.',
    'delete' => 'Sterge'
];