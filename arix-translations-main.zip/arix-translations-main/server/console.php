<?php

return [
    'console' => 'Consola',
    'node-under-maintenance' => 'Nodul acestui server este in prezent in mentenanta si toate actiunile sunt indisponibile.',
    'running-installation-process' => 'Acest server ruleaza in prezent procesul de instalare si majoritatea actiunilor nu sunt disponibile.',
    'being-transferred' => 'Acest server este in prezent transferat catre un alt nod si toate actiunile sunt indisponibile.',
    'type-a-command' => 'Scrie o comanda...',
];