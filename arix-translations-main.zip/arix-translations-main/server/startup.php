<?php

return [
    'startup-settings' => 'Se pornesc setarile',
    'startup-command' => 'Comanda de start',
    'docker-image' => 'Docker Image',
    'read-only' => 'Doar Citire',
    'select-docker-feature' => 'Aceasta este o caracteristica avansata care va permite sa selectati o Imagine Docker pe care sa o utilizati cand rulati aceasta instanta de server.',
    'custom-docker-image' => 'Aceeasta {"server\'s"} Imagine de Docker a fost setat manual de un administator si nu poate fi modificat prin aceasta interfata de utilizare.',
    'variables' => 'Variabile'
];